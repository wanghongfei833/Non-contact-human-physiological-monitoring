from ctypes import *
from enum import Enum
#from typing import Union


MAX_BOX_TEMP_SIZE = 16
MAX_SPOT_TEMP_SIZE = 6
MAX_LINE_TEMP_SIZE = 1
MAX_CIRCLE_TEMP_SIZE = 4
MAX_POLYGON_TEMP_SIZE = 4


class ST_DEVICE_INFO(Structure):
    _pack_ = 1
    _fields_ = [
        ("szManualFacturer", c_char * 32),
        ("szDeviceName", c_char * 32),
        ("szDeviceModel", c_char * 32),
        ("szDeviceType", c_char * 32),
        ("szSerialNumber", c_char * 32),
        ("szHardwareID", c_char * 32),
        ("u32RgbViWidth", c_uint32),
        ("u32RgbViHeight", c_uint32),
        ("reserved", c_uint8 * 56)
    ]


class ST_SEARCH_DEV_INFO(Structure):
    _fields_ = [
        ("IPAddr", c_char * 40),
        ("NetMask", c_char * 40),
        ("MacAddr", c_ubyte * 6),
        ("szDeviceName", c_char * 32),
        ("szDeviceModel", c_char * 32),
        ("szSerialNumber", c_char * 32),
        ("SwMainVer", c_ubyte * 32)
    ]


class ST_TMP_ADDR(Structure):
    _fields_ = [
        ("MacAddr", c_char * 6),
        ("IPAddr", c_char * 40),
        ("NetMask", c_ubyte * 40),
        ("GateWay", c_char * 40)
    ]


class EM_OPER_CODE(Enum):
    OPER_Left = 1  # 左移
    OPER_Right = 2  # 右移
    OPER_Up = 3  # 上移
    OPER_Down = 4  # 下移
    OPER_ZoomUp = 5  # 放大
    OPER_ZoomDown = 6  # 缩小
    OPER_AlphaAdd = 7  # Alpha值增加
    OPER_AlphaSub = 8  # Alpha值减小


class ST_IMG_FUSION_CFG(Structure):
    _pack_ = 1
    _fields_ = [
        ("fScaleX", c_float),
        ("fScaleY", c_float),
        ("iPosX", c_int),
        ("iPosY", c_int),
        ("iFusionDistance", c_int),
        ("fAlphaVisible", c_float),
        ("fAlphaInfrare", c_float),
        ("iAlpha", c_int),
        ("reserved", c_ubyte * 32)
    ]


class ST_PALLET_INFO(Structure):
    _pack_ = 1
    _fields_ = [
        ("ucPalletType", c_ubyte),
        ("reserved", c_ubyte * 7)
    ]


class ST_FLIP_INFO(Structure):
    _pack_ = 1
    _fields_ = [
        ("ucFlipType", c_ubyte),
        ("ucReserved", c_ubyte * 7)
    ]


class ST_BOX_COORD(Structure):
    _pack_ = 1
    _fields_ = [
        ("usBX", c_ushort),
        ("usBY", c_ushort),
        ("usBW", c_ushort),
        ("usBH", c_ushort)
    ]


class ST_POLYGON_COORD(Structure):
    _pack_ = 1
    _fields_ = [
        ("usPX", c_ushort * 32),
        ("usPY", c_ushort * 32),
        ("usPCount", c_ushort)
    ]


class ST_CIRCLE_COORD(Structure):
    _pack_ = 1
    _fields_ = [
        ("usCX", c_ushort),
        ("usCY", c_ushort),
        ("usCR", c_ushort)
    ]


class ST_SPOT_COORD(Structure):
    _pack_ = 1
    _fields_ = [
        ("usSX", c_ushort),
        ("usSY", c_ushort)
    ]


class ST_LINE_COORD(Structure):
    _pack_ = 1
    _fields_ = [
        ("usLHX", c_ushort),
        ("usLHY", c_ushort),
        ("usLTX", c_ushort),
        ("usLTY", c_ushort)
    ]


class ST_ALL_TEMP_COOR(Structure):
    _pack_ = 1
    _fields_ = [
        # ("BoxCoord", POINTER(ST_BOX_COORD)),
        # ("SpotCoord", POINTER(ST_SPOT_COORD)),
        # ("LineCoord", POINTER(ST_LINE_COORD)),
        # ("CircleCoord", POINTER(ST_CIRCLE_COORD)),
        # ("PolygonCoord", POINTER(ST_POLYGON_COORD)),
        ("BoxCoord", ST_BOX_COORD * MAX_BOX_TEMP_SIZE),
        ("SpotCoord", ST_SPOT_COORD * MAX_SPOT_TEMP_SIZE),
        ("LineCoord", ST_LINE_COORD * MAX_LINE_TEMP_SIZE),
        ("CircleCoord", ST_CIRCLE_COORD * MAX_CIRCLE_TEMP_SIZE),
        ("PolygonCoord", ST_POLYGON_COORD * MAX_POLYGON_TEMP_SIZE),
        ("MouseCoord", ST_SPOT_COORD),

        ("BoxEnable", c_ubyte * MAX_BOX_TEMP_SIZE),
        ("SpotEnable", c_ubyte * MAX_SPOT_TEMP_SIZE),
        ("LineEnable", c_ubyte * MAX_LINE_TEMP_SIZE),
        ("CircleEnable", c_ubyte * MAX_CIRCLE_TEMP_SIZE),
        ("PolygonEnable", c_ubyte * MAX_POLYGON_TEMP_SIZE),
        ("MouseEnable", c_ubyte)
    ]


class ST_AREA_OR_LINE_TEMP(Structure):
    _pack_ = 1
    _fields_ = [
        ("iMinT", c_int),
        ("iMaxT", c_int),
        ("iAvgT", c_int),
        ("usHighX", c_ushort),
        ("usHighY", c_ushort),
        ("usLowX", c_ushort),
        ("usLowY", c_ushort)
    ]


class ST_LOCAL_TEMP(Structure):
    _pack_ = 1
    _fields_ = [
        ("stFrameTemp", ST_AREA_OR_LINE_TEMP),
        ("stBoxTemp", ST_AREA_OR_LINE_TEMP * MAX_BOX_TEMP_SIZE),
        ("stLineTemp", ST_AREA_OR_LINE_TEMP * MAX_LINE_TEMP_SIZE),
        ("stCircleTemp", ST_AREA_OR_LINE_TEMP * MAX_CIRCLE_TEMP_SIZE),
        ("stPolygonTemp", ST_AREA_OR_LINE_TEMP * MAX_POLYGON_TEMP_SIZE),
        ("iSpotT", c_int * MAX_SPOT_TEMP_SIZE),
        ("MouseEnable", c_int)
    ]


class ST_ENVIR_PARAM(Structure):
    _pack_ = 1
    _fields_ = [
        ("iEmissivity", c_int),
        ("iAtmosTemp", c_int),
        ("iTargetTemp", c_int),
        ("iAtmosTrans", c_int),
        ("iDistance", c_int),
        ("iCorrection", c_int),
        ("iHumidity", c_int),
        ("iReserved", c_int)
    ]


class ST_ALL_ENVIR_PARAMS(Structure):
    _pack_ = 1
    _fields_ = [
        ("stGlobalEnvParam", ST_ENVIR_PARAM),
        ("stBoxEnvParam", ST_ENVIR_PARAM * MAX_BOX_TEMP_SIZE),
        ("stSpotEnvParam", ST_ENVIR_PARAM * MAX_SPOT_TEMP_SIZE),
        ("stLineEnvParam", ST_ENVIR_PARAM * MAX_LINE_TEMP_SIZE),
        ("stCircleEnvParam", ST_ENVIR_PARAM * MAX_CIRCLE_TEMP_SIZE),
        ("stPolygonEnvParam", ST_ENVIR_PARAM * MAX_POLYGON_TEMP_SIZE)
    ]


class ST_ALARM_PARAM(Structure):
    _pack_ = 1
    _fields_ = [
        ("ucActive", c_ubyte),
        ("ucCondition", c_ubyte),
        ("ucCapture", c_ubyte),
        ("fThreshold", c_float),
        ("fHysteresis", c_float),
        ("iThresholeTime", c_int),
        ("ucDisableCalib", c_ubyte),
        ("ucEmail", c_ubyte),
        ("ucDigital", c_ubyte),
        ("ucDigital2", c_ubyte),
        ("ucFtp", c_ubyte),
        ("ucReserve", c_ubyte * 8)
    ]


class ST_ALL_ALARM_PARAMS(Structure):
    _pack_ = 1
    _fields_ = [
        ("stBoxParam", ST_ALARM_PARAM * MAX_BOX_TEMP_SIZE),
        ("stSpotParam", ST_ALARM_PARAM * MAX_SPOT_TEMP_SIZE),
        ("stLineParam", ST_ALARM_PARAM * MAX_LINE_TEMP_SIZE),
        ("stCircleParam", ST_ALARM_PARAM * MAX_CIRCLE_TEMP_SIZE),
        ("stPolygonParam", ST_ALARM_PARAM * MAX_POLYGON_TEMP_SIZE),
        ("stAlarmInParam", ST_ALARM_PARAM * 2),
    ]


class ST_NET_CFG(Structure):
    _pack_ = 1
    _fields_ = [
        ("uiEnable3G", c_uint),
        ("uiEnableWIFI", c_uint),
        ("uiEnableDHCP", c_uint),
        ("szLocalIpAddr", c_char * 40),
        ("szLocalNetMask", c_char * 40),
        ("szGateWay", c_char * 40),
        ("szDNS1", c_char * 40),
        ("szDNS2", c_char * 40),
        ("uiEnableWIFIDHCP", c_uint),
        ("szWifiIpAddr", c_char * 40),
        ("szWifiNetMask", c_char * 40),
        ("szWIFIGateWay", c_char * 40),
        ("szWIFIDNS1", c_char * 40),
        ("szWIFIDNS2", c_char * 40),
        ("szMainServerAddr", c_char * 40),
        ("uiStartPort", c_uint),
        ("reserved", c_ubyte * 52)
    ]


class ST_RECORD_INFO(Structure):
    _pack_ = 1
    _fields_ = [
        ("ucRecordType", c_ubyte),
        ("ucOperType", c_ubyte),
        ("reserved", c_ubyte * 30)
    ]


class ST_DEV_TIME(Structure):
    _pack_ = 1
    _fields_ = [
        ("uiYear", c_uint),
        ("uiMonth", c_uint),
        ("uiDay", c_uint),
        ("uiHour", c_uint),
        ("uiMin", c_uint),
        ("uiSec", c_uint),
        ("reserved", c_ubyte * 40)
    ]


class ST_INFRA_CFG(Structure):
    _pack_ = 1
    _fields_ = [
        ("iTempRange", c_int),
        ("iTempFrameRate", c_int),
        ("iYUVFrameRate", c_int),
        ("iWidth", c_int),
        ("iHeight", c_int),
        ("iInfraType", c_int),
        ("reserved", c_ubyte * 232)
    ]


class ST_VERSION_INFO(Structure):
    _pack_ = 1
    _fields_ = [
        ("szSysVer", c_char * 32),
        ("szKernelVer", c_char * 32),
        ("szFirmwareVer", c_char * 24),
        ("szProductVer", c_char * 24)
    ]


class ST_RUN_STATE(Structure):
    _pack_ = 1
    _fields_ = [
        ("ucSDState", c_ubyte),
        ("ucIrState", c_ubyte),
        ("ucRgbState", c_ubyte),
        ("ucRecording", c_ubyte),
        ("ucFusionState", c_ubyte),
        ("ucReserve", c_ubyte * (64 - 5))
    ]


class ST_MEDIA_CFG(Structure):
    _pack_ = 1
    _fields_ = [
        ("uiAlarmRecordTime", c_uint),
        ("uiManulRecordTime", c_uint),
        ("uiMaxRecordKBytes", c_uint),
        ("uiIrViWidth", c_uint),
        ("uiIrViHeight", c_uint),
        ("uiRgbViWidth", c_uint),
        ("uiRgbViHeight", c_uint),
        ("uiIrWidth0", c_uint),
        ("uiIrHeight0", c_uint),
        ("uiIrBitRate0", c_uint),
        ("uiIrCBR0", c_uint),
        ("uiIrFPS0", c_uint),
        ("uiIrGOP0", c_uint),
        ("uiIrRotation0", c_uint),
        ("uiIrProfile0", c_uint),
        ("uiIrWidth1", c_uint),
        ("uiIrHeight1", c_uint),
        ("uiIrBitRate1", c_uint),
        ("uiIrCBR1", c_uint),
        ("uiIrFPS1", c_uint),
        ("uiIrGOP1", c_uint),
        ("uiIrRotation1", c_uint),
        ("uiIrProfile1", c_uint),
        ("uiIrWidth2", c_uint),
        ("uiIrHeight2", c_uint),
        ("uiIrBitRate2", c_uint),
        ("uiIrCBR2", c_uint),
        ("uiIrFPS2", c_uint),
        ("uiIrGOP2", c_uint),
        ("uiIrRotation2", c_uint),
        ("uiIrProfile2", c_uint),
        ("uiRgbWidth0", c_uint),
        ("uiRgbHeight0", c_uint),
        ("uiRgbBitRate0", c_uint),
        ("uiRgbCBR0", c_uint),
        ("uiRgbFPS0", c_uint),
        ("uiRgbGOP0", c_uint),
        ("uiRgbRotation0", c_uint),
        ("uiRgbProfile0", c_uint),
        ("uiRgbWidth1", c_uint),
        ("uiRgbHeight1", c_uint),
        ("uiRgbBitRate1", c_uint),
        ("uiRgbCBR1", c_uint),
        ("uiRgbFPS1", c_uint),
        ("uiRgbGOP1", c_uint),
        ("uiRgbRotation1", c_uint),
        ("uiRgbProfile1", c_uint),
        ("uiRgbWidth2", c_uint),
        ("uiRgbHeight2", c_uint),
        ("uiRgbBitRate2", c_uint),
        ("uiRgbCBR2", c_uint),
        ("uiRgbFPS2", c_uint),
        ("uiRgbGOP2", c_uint),
        ("uiRgbRotation2", c_uint),
        ("uiRgbProfile2", c_uint),
        ("reserved", c_ubyte * (4 * (100 - 55)))
    ]


class UN_PTZ_CFG(Union):
    _pack_ = 1
    _fields_ = [
        ('iProtocol', c_int),
        ('iBaudRate', c_int),
        ('iBits', c_int),
        ('cParity', c_char),
        ('iStop', c_int),
    ]


class ST_PTZ_CFG(Structure):
    _pack_ = 1
    _fields_ = [
        ("iOperCode", c_ubyte),
        ("unPtzCfg", UN_PTZ_CFG)
    ]


class ST_COM_CFG(Structure):
    _pack_ = 1
    _fields_ = [
        ("iBaudRate", c_int),
        ("iBits", c_int),
        ("cParity", c_char),
        ("iStop", c_int),
        ("reserved", c_ubyte * (32 - 13))
    ]


class ST_TFTP_CFG(Structure):
    _pack_ = 1
    _fields_ = [
        ("iEnableTimingSend", c_int),
        ("iTimeIntervalS", c_int),
        ("szServerAddr", c_char * 32),
        ("reserved", c_ubyte * (64 - 40))
    ]


class ST_EMAIL_CFG(Structure):
    _pack_ = 1
    _fields_ = [
        ("iEnableEmail", c_int),
        ("szSendEmail", c_char * 64),
        ("szSendEmailPwd", c_char * 64),
        ("szRecvEmail", c_char * 64),
        ("reserved", c_ubyte * (256 - 196))
    ]


class EM_OSD_ID(Enum):
    OSD_ID_PAINT = 0
    OSD_ID_USER = 1
    OSD_ID_TIME = 2
    OSD_ID_LOGO = 3
    OSD_ID_LNGLAT = 4
    OSD_ID_RECORD = 5
    OSD_ID_BUTT = 6


class ST_OSD(Structure):
    _pack_ = 1
    _fields_ = [
        ("uiEnable", c_uint),
        ("iOsdX", c_int),
        ("iOsdY", c_int),
        ("uiOsdW", c_uint),
        ("uiOsdH", c_uint),
        ("uiOsdFgAlpha", c_uint),
        ("uiOsdBgAlpha", c_uint),
        ("uiOsdBgColor", c_uint)
    ]


class ST_OSD_CFG(Structure):
    _pack_ = 1
    _fields_ = [
        ("stIrOsd", ST_OSD * EM_OSD_ID.OSD_ID_BUTT.value),
        ("stRgbOsd", ST_OSD * EM_OSD_ID.OSD_ID_BUTT.value),
        ("szUserOsdString", c_char * 32),
        ("reserved", c_ubyte * (512 - 8 * 4 * 10 - 32))
    ]


class ST_SENSOR_DATA(Structure):
    _pack_ = 1
    _fields_ = [
        ("sTemperature", c_short),
        ("sHumidity", c_short),
        ("sDistance", c_short),
        ("Reserved", c_ubyte * (64 - 6)),
    ]


class ST_EXPOSURE_PARAM(Structure):
    _pack_ = 1
    _fields_ = [
        ("ucElectronicShutter", c_ubyte),
        ("ucAgc", c_ubyte),
        ("ucIsAutoExposure", c_ubyte),
        ("ucIsAutoAGC", c_ubyte),
        ("ucReserve", c_ubyte * (64 - 4)),
    ]
