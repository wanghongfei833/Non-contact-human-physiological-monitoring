import ctypes
import os
import sys
from ctypes import *
from ctypes import util
from rtkb_sdk.Structures import *
import inspect


def get_calling_module():
    # frame = inspect.currentframe().f_back
    # module = inspect.getmodule(frame)
    # if hasattr(module, '__name__'):
    #     return module.__name__
    # else:
    #     filename = inspect.getsourcefile(frame)
    #     package_path = os.path.dirname(filename).split('/')[-1]
    #     return package_path
    # filename = inspect.getsourcefile(frame)
    filename = inspect.getfile(inspect.currentframe())
    # print("当前脚本路径:", filename)
    package_path = os.path.dirname(filename)
    # print("当前包路径:", package_path)
    return package_path


def load_dll():
    so_path = get_calling_module()

    if 'linux' in sys.platform:
        so_name = so_path + "/libRtNet.so"
    else:
        so_name = so_path + "/RtNet.dll"

    dll = cdll.LoadLibrary(so_name)
    # dll = None
    # so_name = util.find_library('RtNet')
    # if so_name is not None:
    #     dll = cdll.LoadLibrary(so_name)
    return dll


# 回调函数类型定义
if 'linux' in sys.platform:
    fun_ctype = CFUNCTYPE
else:
    fun_ctype = WINFUNCTYPE

TEMP_CALLBACK = fun_ctype(None, POINTER(c_ushort), c_uint, c_uint, c_ulonglong, c_void_p)
JPEG_CALLBACK = fun_ctype(None, POINTER(c_ubyte), c_uint, c_uint, c_uint, c_ulonglong, c_void_p)
DATA_CALLBACK = fun_ctype(None, POINTER(c_ubyte), c_uint, c_uint, c_uint, c_ulonglong, c_void_p)


class RtNet:
    def __init__(self):
        self.dll = load_dll()

    def Init(self):
        myFunc = self.dll.RtNet_Init
        myFunc.restype = c_int
        return myFunc()

    def Exit(self):
        self.dll.RtNet_Exit()

    def GetDeviceInfo(self, pszServerIP, pstDevInfo):
        myFunc = self.dll.RtNet_GetDeviceInfo
        # size = sizeof(ST_DEVICE_INFO) * 1
        # p_buff = create_string_buffer(size)
        # p_struct = POINTER(ST_DEVICE_INFO)(p_buff)
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_DEVICE_INFO)]
        # iRet = myFunc(pszServerIP, p_struct)
        iRet = myFunc(pszServerIP, byref(pstDevInfo))
        # print(p_struct[0].szManualFacturer, p_struct[0].szDeviceName)
        return iRet
        # return myFunc(pszServerIP, byref(pstDevInfo))

    def SetDeviceInfo(self, pszServerIP, pstDevInfo):
        myFunc = self.dll.RtCore_SetDeviceInfo
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_DEVICE_INFO)]
        iRet = myFunc(pszServerIP, byref(pstDevInfo))
        return iRet

    def StartTemperatureStream(self, pszServerIP, TEMP_CALLBACK_FUNC, pArg):
        myFunc = self.dll.RtNet_StartTemperatureStream
        myFunc.restype = c_void_p
        myFunc.argtypes = [c_char_p, TEMP_CALLBACK, c_void_p]
        TEMP_STREAMER = myFunc(pszServerIP, TEMP_CALLBACK_FUNC, pArg)
        return TEMP_STREAMER

    def StopTemperatureData(self, TEMP_STREAMER):
        myFunc = self.dll.RtNet_StopTemperatureData
        myFunc.restype = c_int
        myFunc.argtypes = [c_void_p]
        iRet = myFunc(TEMP_STREAMER)
        return iRet

    def StartRgbJpegStream(self, pszServerIP, JPEG_CALLBACK_FUNC, pArg):
        myFunc = self.dll.RtNet_StartRgbJpegStream
        myFunc.restype = c_void_p
        myFunc.argtypes = [c_char_p, JPEG_CALLBACK, c_void_p]
        JPEG_STREAMER = myFunc(pszServerIP, JPEG_CALLBACK_FUNC, pArg)
        return JPEG_STREAMER

    def StopRgbJpegStream(self, JPEG_STREAMER):
        myFunc = self.dll.RtNet_StopRgbJpegStream
        myFunc.restype = c_int
        myFunc.argtypes = [c_void_p]
        iRet = myFunc(JPEG_STREAMER)
        return iRet

    def StartIrJpegStream(self, pszServerIP, JPEG_CALLBACK_FUNC, pArg):
        myFunc = self.dll.RtNet_StartIrJpegStream
        myFunc.restype = c_void_p
        myFunc.argtypes = [c_char_p, JPEG_CALLBACK, c_void_p]
        JPEG_STREAMER = myFunc(pszServerIP, JPEG_CALLBACK_FUNC, pArg)
        return JPEG_STREAMER

    def StopIrJpegStream(self, JPEG_STREAMER):
        myFunc = self.dll.RtNet_StopIrJpegStream
        myFunc.restype = c_int
        myFunc.argtypes = [c_void_p]
        iRet = myFunc(JPEG_STREAMER)
        return iRet

    def StartDataStream(self, pszServerIP, sPort, DATA_CALLBACK_FUNC, pArg):
        myFunc = self.dll.RtNet_StartDataStream
        myFunc.restype = c_void_p
        myFunc.argtypes = [c_char_p, c_short, DATA_CALLBACK, c_void_p]
        DATA_STREAMER = myFunc(pszServerIP, sPort, DATA_CALLBACK_FUNC, pArg)
        return DATA_STREAMER

    def StopDataStream(self, DATA_STREAMER):
        myFunc = self.dll.RtNet_StopDataStream
        myFunc.restype = c_int
        myFunc.argtypes = [c_void_p]
        iRet = myFunc(DATA_STREAMER)
        return iRet

    def SearchDevice(self, pstSearchDevList, iTimeOutS):
        myFunc = self.dll.RtNet_SearchDevice
        myFunc.restype = c_int
        myFunc.argtypes = [POINTER(ST_SEARCH_DEV_INFO), POINTER(c_int), c_int]
        size = sizeof(ST_SEARCH_DEV_INFO) * 16
        p_buff = create_string_buffer(size)
        p_struct = POINTER(ST_SEARCH_DEV_INFO)(p_buff)
        piDevCount = c_int(0)
        iRet = myFunc(p_struct, byref(piDevCount), iTimeOutS)
        for i in range(piDevCount.value):
            pstSearchDevList.append(p_struct[i])
        return iRet

    def SetTmpAddr(self, pstTmpAddr):
        myFunc = self.dll.RtNet_SetTmpAddr
        myFunc.restype = c_int
        myFunc.argtypes = [POINTER(ST_TMP_ADDR)]
        iRet = myFunc(byref(pstTmpAddr))
        return iRet

    def DetectFace(self, pszServerIP):
        myFunc = self.dll.RtNet_DetectFace
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(c_int)]
        piTemp = c_int(0)
        iRet = myFunc(pszServerIP, byref(piTemp))
        return [iRet, piTemp.value]

    def DetectMultipleFace(self, pszServerIP, iTempsList):
        myFunc = self.dll.RtNet_DetectMultipleFace
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(c_int), POINTER(c_int)]
        piCount = c_int(0)
        size = sizeof(c_int) * 16
        p_buff = create_string_buffer(size)
        p_array = POINTER(c_int)(p_buff)
        iRet = myFunc(pszServerIP, p_array, byref(piCount))
        for i in range(piCount.value):
            iTempsList.append(p_array[i])
        return iRet

    def HttpDownload(self, pszServerIP, iPort, pszUrl, pszFile):
        myFunc = self.dll.RtNet_HttpDownload
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, c_int, c_char_p, c_char_p]
        iRet = myFunc(pszServerIP, c_int(iPort), pszUrl, pszFile)
        return iRet

    def ImageFusionTuning(self, pszServerIP, emOper):
        myFunc = self.dll.RtNet_ImageFusionTuning
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, c_int]
        iRet = myFunc(pszServerIP, c_int(emOper.value))
        return iRet

    def SaveFusionTuning(self, pszServerIP):
        myFunc = self.dll.RtNet_SaveFusionTuning
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p]
        iRet = myFunc(pszServerIP)
        return iRet

    def GetFusionParam(self, pszServerIP, pstImgFustionCfg):
        myFunc = self.dll.RtNet_GetFusionParam
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_IMG_FUSION_CFG)]
        iRet = myFunc(pszServerIP, byref(pstImgFustionCfg))
        return iRet

    def SetFusionParam(self, pszServerIP, pstImgFustionCfg):
        myFunc = self.dll.RtNet_SetFusionParam
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_IMG_FUSION_CFG)]
        iRet = myFunc(pszServerIP, byref(pstImgFustionCfg))
        return iRet

    def GetPallet(self, pszServerIP, pstPalletInfo):
        myFunc = self.dll.RtNet_GetPallet
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_PALLET_INFO)]
        iRet = myFunc(pszServerIP, byref(pstPalletInfo))
        return iRet

    def SetPallet(self, pszServerIP, pstPalletInfo):
        myFunc = self.dll.RtNet_SetPallet
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_PALLET_INFO)]
        iRet = myFunc(pszServerIP, byref(pstPalletInfo))
        return iRet

    def GetImgFlip(self, pszServerIP, pstFlipInfo):
        myFunc = self.dll.RtNet_GetImgFlip
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_FLIP_INFO)]
        iRet = myFunc(pszServerIP, byref(pstFlipInfo))
        return iRet

    def SetImgFlip(self, pszServerIP, pstFlipInfo):
        myFunc = self.dll.RtNet_SetImgFlip
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_FLIP_INFO)]
        iRet = myFunc(pszServerIP, byref(pstFlipInfo))
        return iRet

    def SetShutterCorrection(self, pszServerIP, ucValue):
        myFunc = self.dll.RtNet_SetShutterCorrection
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, c_ubyte]
        iRet = myFunc(pszServerIP, c_ubyte(ucValue))
        return iRet

    def GetAutoCorrection(self, pszServerIP):
        myFunc = self.dll.RtNet_GetAutoCorrection
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(c_uint)]
        puiValue = c_uint(0)
        iRet = myFunc(pszServerIP, byref(puiValue))
        return [iRet, puiValue.value]

    def SetAutoCorrection(self, pszServerIP, uiValue):
        myFunc = self.dll.RtNet_SetAutoCorrection
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, c_uint]
        iRet = myFunc(pszServerIP, c_uint(uiValue))
        return iRet

    def GetLampState(self, pszServerIP):
        myFunc = self.dll.RtNet_GetLampState
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(c_ubyte)]
        pucOn = c_ubyte(0)
        iRet = myFunc(pszServerIP, byref(pucOn))
        return [iRet, pucOn.value]

    def SetLampState(self, pszServerIP, ucOn):
        myFunc = self.dll.RtNet_SetLampState
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, c_ubyte]
        iRet = myFunc(pszServerIP, c_ubyte(ucOn))
        return iRet

    def GetTempRange(self, pszServerIP):
        myFunc = self.dll.RtNet_GetTempRange
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(c_ubyte)]
        pucValue = c_ubyte(0)
        iRet = myFunc(pszServerIP, byref(pucValue))
        return [iRet, pucValue.value]

    def SetTempRange(self, pszServerIP, ucValue):
        myFunc = self.dll.RtNet_SetTempRange
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, c_ubyte]
        iRet = myFunc(pszServerIP, c_ubyte(ucValue))
        return iRet

    def SnapJpeg(self, pszServerIP):
        myFunc = self.dll.RtNet_SnapJpeg
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p]
        iRet = myFunc(pszServerIP)
        return iRet

    def GetAllTempCoor(self, pszServerIP, pstAllTempCoor):
        myFunc = self.dll.RtNet_GetAllTempCoor
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_ALL_TEMP_COOR)]

        # # 创建嵌套结构体数组
        # boxCoord_array_type = ST_BOX_COORD * MAX_BOX_TEMP_SIZE
        # boxCoord_array = boxCoord_array_type()
        # pstAllTempCoor.BoxCoord = boxCoord_array
        #
        # spotCoord_array_type = ST_SPOT_COORD * MAX_SPOT_TEMP_SIZE
        # spotCoord_array = spotCoord_array_type()
        # pstAllTempCoor.SpotCoord = spotCoord_array
        #
        # lineCoord_array_type = ST_LINE_COORD * MAX_LINE_TEMP_SIZE
        # lineCoord_array = lineCoord_array_type()
        # pstAllTempCoor.LineCoord = lineCoord_array
        #
        # circleCoord_array_type = ST_CIRCLE_COORD * MAX_CIRCLE_TEMP_SIZE
        # circleCoord_array = circleCoord_array_type()
        # pstAllTempCoor.CircleCoord = circleCoord_array
        #
        # polygonCoord_array_type = ST_POLYGON_COORD * MAX_POLYGON_TEMP_SIZE
        # polygonCoord_array = polygonCoord_array_type()
        # pstAllTempCoor.PolygonCoord = polygonCoord_array
        #
        # boxEnable_array_type = c_ubyte * MAX_BOX_TEMP_SIZE
        # boxEnable_array = boxEnable_array_type()
        # pstAllTempCoor.BoxEnable = boxEnable_array
        #
        # spotEnable_array_type = c_ubyte * MAX_SPOT_TEMP_SIZE
        # spotEnable_array = spotEnable_array_type()
        # pstAllTempCoor.SpotEnable = spotEnable_array
        #
        # lineEnable_array_type = c_ubyte * MAX_LINE_TEMP_SIZE
        # lineEnable_array = lineEnable_array_type()
        # pstAllTempCoor.LineEnable = lineEnable_array
        #
        # circleEnable_array_type = c_ubyte * MAX_CIRCLE_TEMP_SIZE
        # circleEnable_array = circleEnable_array_type()
        # pstAllTempCoor.CircleEnable = circleEnable_array
        #
        # polygonEnable_array_type = c_ubyte * MAX_POLYGON_TEMP_SIZE
        # polygonEnable_array = polygonEnable_array_type()
        # pstAllTempCoor.PolygonEnable = polygonEnable_array

        iRet = myFunc(pszServerIP, byref(pstAllTempCoor))
        return iRet

    def SetAllTempCoor(self, pszServerIP, pstAllTempCoor):
        myFunc = self.dll.RtNet_SetAllTempCoor
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_ALL_TEMP_COOR)]
        iRet = myFunc(pszServerIP, byref(pstAllTempCoor))
        return iRet

    def GetLocalTemperature(self, pszServerIP, pstLocalTemp):
        myFunc = self.dll.RtNet_GetLocalTemperature
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_LOCAL_TEMP)]
        iRet = myFunc(pszServerIP, byref(pstLocalTemp))
        return iRet

    def GetVideoMode(self, pszServerIP):
        myFunc = self.dll.RtNet_GetVideoMode
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(c_ubyte)]
        pucVideoMode = c_ubyte(0)
        iRet = myFunc(pszServerIP, byref(pucVideoMode))
        return [iRet, pucVideoMode.value]

    def SetVideoMode(self, pszServerIP, ucVideoMode):
        myFunc = self.dll.RtNet_SetVideoMode
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, c_ubyte]
        iRet = myFunc(pszServerIP, c_ubyte(ucVideoMode))
        return iRet

    def GetEnvirParam(self, pszServerIP, pstAllEnvParams):
        myFunc = self.dll.RtNet_GetEnvirParam
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_ALL_ENVIR_PARAMS)]
        iRet = myFunc(pszServerIP, byref(pstAllEnvParams))
        return iRet

    def SetEnvirParam(self, pszServerIP, pstAllEnvParams):
        myFunc = self.dll.RtNet_SetEnvirParam
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_ALL_ENVIR_PARAMS)]
        iRet = myFunc(pszServerIP, byref(pstAllEnvParams))
        return iRet

    def GetAnalogVideoMode(self, pszServerIP):
        myFunc = self.dll.RtNet_GetAnalogVideoMode
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(c_ubyte)]
        pucModel = c_ubyte(0)
        iRet = myFunc(pszServerIP, byref(pucModel))
        return [iRet, pucModel.value]

    def SetAnalogVideoMode(self, pszServerIP, ucModel):
        myFunc = self.dll.RtNet_SetAnalogVideoMode
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, c_ubyte]
        iRet = myFunc(pszServerIP, c_ubyte(ucModel))
        return iRet

    def GetAlarmParam(self, pszServerIP, pstAllAlarmParams):
        myFunc = self.dll.RtNet_GetAlarmParam
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_ALL_ALARM_PARAMS)]
        iRet = myFunc(pszServerIP, byref(pstAllAlarmParams))
        return iRet

    def SetAlarmParam(self, pszServerIP, pstAllAlarmParams):
        myFunc = self.dll.RtNet_SetAlarmParam
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_ALL_ALARM_PARAMS)]
        iRet = myFunc(pszServerIP, byref(pstAllAlarmParams))
        return iRet

    def GetNetworkCfg(self, pszServerIP, pstNetCfg):
        myFunc = self.dll.RtNet_GetNetworkCfg
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_NET_CFG)]
        iRet = myFunc(pszServerIP, byref(pstNetCfg))
        return iRet

    def SetNetworkCfg(self, pszServerIP, pstNetCfg):
        myFunc = self.dll.RtNet_SetNetworkCfg
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_NET_CFG)]
        iRet = myFunc(pszServerIP, byref(pstNetCfg))
        return iRet

    def RecordVideo(self, pszServerIP, pstRecordInfo):
        myFunc = self.dll.RtNet_RecordVideo
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_RECORD_INFO)]
        iRet = myFunc(pszServerIP, byref(pstRecordInfo))
        return iRet

    def GetRecordType(self, pszServerIP):
        myFunc = self.dll.RtNet_GetRecordType
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(c_ubyte)]
        pucType = c_ubyte(0)
        iRet = myFunc(pszServerIP, byref(pucType))
        return [iRet, pucType.value]

    def SetRecordType(self, pszServerIP, ucType):
        myFunc = self.dll.RtNet_SetRecordType
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, c_ubyte]
        iRet = myFunc(pszServerIP, c_ubyte(ucType))
        return iRet

    def GetDevTime(self, pszServerIP, pstDevTime):
        myFunc = self.dll.RtNet_GetDevTime
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_DEV_TIME)]
        iRet = myFunc(pszServerIP, byref(pstDevTime))
        return iRet

    def SetDevTime(self, pszServerIP, pstDevTime):
        myFunc = self.dll.RtNet_SetDevTime
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_DEV_TIME)]
        iRet = myFunc(pszServerIP, byref(pstDevTime))
        return iRet

    def SnapShot(self, pszServerIP, ucType):
        myFunc = self.dll.RtNet_SnapShot
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, c_ubyte]
        iRet = myFunc(pszServerIP, c_ubyte(ucType))
        return iRet

    def Reboot(self, pszServerIP):
        myFunc = self.dll.RtNet_Reboot
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p]
        iRet = myFunc(pszServerIP)
        return iRet

    def ResetFactoryDefault(self, pszServerIP):
        myFunc = self.dll.RtNet_ResetFactoryDefault
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p]
        iRet = myFunc(pszServerIP)
        return iRet

    def GetInfraCfg(self, pszServerIP, pstInfraCfg):
        myFunc = self.dll.RtNet_GetInfraCfg
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_INFRA_CFG)]
        iRet = myFunc(pszServerIP, byref(pstInfraCfg))
        return iRet

    def SetInfraCfg(self, pszServerIP, pstInfraCfg):
        myFunc = self.dll.RtNet_SetInfraCfg
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_INFRA_CFG)]
        iRet = myFunc(pszServerIP, byref(pstInfraCfg))
        return iRet

    def GetVersionInfo(self, pszServerIP, pstVersionInfo):
        myFunc = self.dll.RtNet_GetVersionInfo
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_VERSION_INFO)]
        iRet = myFunc(pszServerIP, byref(pstVersionInfo))
        return iRet

    def GetRunState(self, pszServerIP, pstRunState):
        myFunc = self.dll.RtNet_GetRunState
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_RUN_STATE)]
        iRet = myFunc(pszServerIP, byref(pstRunState))
        return iRet

    def GetMediaCfg(self, pszServerIP, pstMediaCfg):
        myFunc = self.dll.RtNet_GetMediaCfg
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_MEDIA_CFG)]
        iRet = myFunc(pszServerIP, byref(pstMediaCfg))
        return iRet

    def SetMediaCfg(self, pszServerIP, pstMediaCfg):
        myFunc = self.dll.RtNet_SetMediaCfg
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_MEDIA_CFG)]
        iRet = myFunc(pszServerIP, byref(pstMediaCfg))
        return iRet

    def SetPtzCfg(self, pszServerIP, pstPtzCfg):
        myFunc = self.dll.RtNet_SetPtzCfg
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_PTZ_CFG)]
        iRet = myFunc(pszServerIP, byref(pstPtzCfg))
        return iRet

    def GetComCfg(self, pszServerIP, pstComCfg):
        myFunc = self.dll.RtNet_GetComCfg
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_COM_CFG)]
        iRet = myFunc(pszServerIP, byref(pstComCfg))
        return iRet

    def SetComCfg(self, pszServerIP, pstComCfg):
        myFunc = self.dll.RtNet_SetComCfg
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_COM_CFG)]
        iRet = myFunc(pszServerIP, byref(pstComCfg))
        return iRet

    def ComSendData(self, pszServerIP, pszData, iLen):
        myFunc = self.dll.RtNet_ComSendData
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(c_ubyte), c_int]
        # ubyte_array = c_ubyte * iLen
        iRet = myFunc(pszServerIP, byref(pszData), iLen)
        return iRet

    def GetTftpCfg(self, pszServerIP, pstTftpCfg):
        myFunc = self.dll.RtNet_GetTftpCfg
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_TFTP_CFG)]
        iRet = myFunc(pszServerIP, byref(pstTftpCfg))
        return iRet

    def SetTftpCfg(self, pszServerIP, pstTftpCfg):
        myFunc = self.dll.RtNet_SetTftpCfg
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_TFTP_CFG)]
        iRet = myFunc(pszServerIP, byref(pstTftpCfg))
        return iRet

    def GetEmailCfg(self, pszServerIP, pstEmailCfg):
        myFunc = self.dll.RtNet_GetEmailCfg
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_EMAIL_CFG)]
        iRet = myFunc(pszServerIP, byref(pstEmailCfg))
        return iRet

    def SetEmailCfg(self, pszServerIP, pstEmailCfg):
        myFunc = self.dll.RtNet_SetEmailCfg
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_EMAIL_CFG)]
        iRet = myFunc(pszServerIP, byref(pstEmailCfg))
        return iRet

    def GetOsdCfg(self, pszServerIP, pstOsdCfg):
        myFunc = self.dll.RtNet_GetOsdCfg
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_OSD_CFG)]
        iRet = myFunc(pszServerIP, byref(pstOsdCfg))
        return iRet

    def SetOsdCfg(self, pszServerIP, pstOsdCfg):
        myFunc = self.dll.RtNet_SetOsdCfg
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_OSD_CFG)]
        iRet = myFunc(pszServerIP, byref(pstOsdCfg))
        return iRet

    def FormatSDCard(self, pszServerIP):
        myFunc = self.dll.RtNet_FormatSDCard
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p]
        iRet = myFunc(pszServerIP)
        return iRet

    def GetFormatSDCardStatus(self, pszServerIP):
        myFunc = self.dll.RtNet_GetFormatSDCardStatus
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(c_ubyte)]
        pucStatus = c_ubyte(0)
        iRet = myFunc(pszServerIP, byref(pucStatus))
        return [iRet, pucStatus.value]

    def GetSensorData(self, pszServerIP, pstSensorData):
        myFunc = self.dll.RtNet_GetSensorData
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_SENSOR_DATA)]
        iRet = myFunc(pszServerIP, byref(pstSensorData))
        return iRet

    def TestTrigger(self, pszServerIP):
        myFunc = self.dll.RtNet_TestTrigger
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p]
        iRet = myFunc(pszServerIP)
        return iRet

    def GetAntiFlicker(self, pszServerIP):
        myFunc = self.dll.RtNet_GetAntiFlicker
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(c_ubyte)]
        pucType = c_ubyte(0)
        iRet = myFunc(pszServerIP, byref(pucType))
        return [iRet, pucType.value]

    def SetAntiFlicker(self, pszServerIP, ucType):
        myFunc = self.dll.RtNet_SetAntiFlicker
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, c_ubyte]
        iRet = myFunc(pszServerIP, c_ubyte(ucType))
        return iRet

    def GetExposure(self, pszServerIP, pstExposureParam):
        myFunc = self.dll.RtNet_GetExposure
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_EXPOSURE_PARAM)]
        iRet = myFunc(pszServerIP, byref(pstExposureParam))
        return iRet

    def SetExposure(self, pszServerIP, pstExposureParam):
        myFunc = self.dll.RtNet_SetExposure
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, POINTER(ST_EXPOSURE_PARAM)]
        iRet = myFunc(pszServerIP, byref(pstExposureParam))
        return iRet

    def NormalTempCali(self, pszServerIP, iStep):
        myFunc = self.dll.RtNet_NormalTempCali
        myFunc.restype = c_int
        myFunc.argtypes = [c_char_p, c_int]
        iRet = myFunc(pszServerIP, c_int(iStep))
        return iRet

